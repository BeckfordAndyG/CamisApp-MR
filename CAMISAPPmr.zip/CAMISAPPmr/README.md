# CamisApp
Proyecto entregable para Mario Vargas Montes — 13 ago

## Contenido del paquete
- `index.html` — Página de inicio con menú responsive.
- `productos.html` — Página demo para listar productos.
- `resultados.html` — Página con búsqueda, filtros, ordenamiento y paginación.
- `perfil.html` — Página demo de perfil.
- `styles.css` — Estilos del proyecto.
- `script.js` — Lógica JS que simula datos y maneja filtros/paginación.
- `README.md` — Este archivo.
- `CamisApp.zip` — Archivo comprimido listo para entregar (generado).

## Cambios funcionales (para la entrega)
- Menú de navegación funcional y responsive (Inicio, Productos, Resultados, Perfil).
- Página de Resultados con:
  - Búsqueda por nombre.
  - Filtro por talla.
  - Ordenamiento por precio y fecha (más nuevo).
  - Paginación.
  - Tarjetas con imagen, nombre, tallas y precio.
- Validaciones básicas y mensajes (ej. botón 'Ver' muestra alerta).
- Estructura lista para subir a GitHub y descripcion para el profesor.

## Cómo probar localmente
1. Descomprime `CamisApp.zip`.
2. Abre `index.html` en tu navegador (no requiere servidor).
3. Navega a "Resultados" y prueba búsqueda, filtros y paginación.

## Instrucciones para Git
```bash
git init
git add .
git commit -m "Entrega: CamisApp - menú y resultados"
git branch -M main
# Crear repo en GitHub y añadir remote:
git remote add origin https://github.com/TU_USUARIO/CamisApp.git
git push -u origin main
```

Saludos — si quieres puedo generar una versión con backend ASP.NET o agregar imágenes reales.
