// Menu toggle
document.addEventListener('click', function(e){
  const toggle = document.getElementById('nav-toggle');
  const nav = document.getElementById('nav');
  if(!toggle) return;
  if(e.target === toggle){
    nav.classList.toggle('show');
  }
});

// Sample dataset (simula productos)
const products = [
  {id:1,name:'Camiseta A',size:['S','M'],price:12.99,created:'2025-08-01',color:'Blanco'},
  {id:2,name:'Camiseta B',size:['M','L'],price:19.50,created:'2025-09-15',color:'Negro'},
  {id:3,name:'Camiseta C',size:['L','XL'],price:9.99,created:'2025-07-22',color:'Rojo'},
  {id:4,name:'Camiseta D',size:['S','M','L'],price:25.00,created:'2025-10-02',color:'Azul'},
  {id:5,name:'Camiseta E',size:['M'],price:15.75,created:'2025-06-10',color:'Verde'},
  {id:6,name:'Camiseta F',size:['S','L'],price:29.00,created:'2025-10-20',color:'Amarillo'},
  {id:7,name:'Camiseta G',size:['XL'],price:8.50,created:'2025-05-11',color:'Negro'},
  {id:8,name:'Camiseta H',size:['M','L'],price:13.20,created:'2025-09-01',color:'Blanco'}
];

// Small SVG data URIs for placeholder images by id
function placeholderDataURI(text){
  const svg = `<svg xmlns='http://www.w3.org/2000/svg' width='600' height='400'><rect width='100%' height='100%' fill='%23e9eefb'/><text x='50%' y='50%' dominant-baseline='middle' text-anchor='middle' font-size='28' fill='%230b74ff' font-family='Arial, sans-serif'>${text}</text></svg>`;
  return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg);
}

// Render products into a given container
function renderProducts(list, containerId, page=1, perPage=6){
  const container = document.getElementById(containerId);
  if(!container) return;
  container.innerHTML = '';
  const start = (page-1)*perPage;
  const paginated = list.slice(start, start+perPage);
  paginated.forEach(p => {
    const div = document.createElement('div');
    div.className = 'product';
    div.innerHTML = `
      <img src="${placeholderDataURI(p.name)}" alt="${p.name}">
      <div><strong>${p.name}</strong></div>
      <div>Tallas: ${p.size.join(', ')}</div>
      <div class="price">₡ ${p.price.toFixed(2)}</div>
      <div style="margin-top:auto"><button class="btn" onclick="alert('Ver ${p.name}')">Ver</button></div>
    `;
    container.appendChild(div);
  });
  // pagination
  const totalPages = Math.max(1, Math.ceil(list.length / perPage));
  const pagDiv = document.getElementById('pagination');
  if(pagDiv){
    pagDiv.innerHTML = '';
    for(let i=1;i<=totalPages;i++){
      const b = document.createElement('button');
      b.className = 'page-btn' + (i===page?' active':'');
      b.textContent = i;
      b.onclick = ()=> renderProducts(list, containerId, i, perPage);
      pagDiv.appendChild(b);
    }
  }
}

// Apply filters and search from the controls on resultados.html
function applyFiltersAndRender(){
  const search = document.getElementById('search') ? document.getElementById('search').value.trim().toLowerCase() : '';
  const size = document.getElementById('filter-size') ? document.getElementById('filter-size').value : '';
  const sort = document.getElementById('sort') ? document.getElementById('sort').value : 'default';
  let result = products.slice();

  if(search){
    result = result.filter(p=> p.name.toLowerCase().includes(search));
  }
  if(size){
    result = result.filter(p=> p.size.includes(size));
  }
  if(sort === 'price-asc') result.sort((a,b)=> a.price - b.price);
  if(sort === 'price-desc') result.sort((a,b)=> b.price - a.price);
  if(sort === 'new') result.sort((a,b)=> new Date(b.created) - new Date(a.created));

  renderProducts(result, 'results', 1, 6);
  // also fill productos page quickly
  renderProducts(result, 'product-grid', 1, 8);
}

// Wire controls
document.addEventListener('DOMContentLoaded', ()=>{
  applyFiltersAndRender();
  const inputs = ['search','filter-size','sort'];
  inputs.forEach(id=>{
    const el = document.getElementById(id);
    if(el) el.addEventListener('input', applyFiltersAndRender);
  });
});